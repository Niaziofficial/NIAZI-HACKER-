// NIAZI-MD Bot (Node.js + Baileys)
// Bot name: NIAZI-MD
// Language: English (friendly tone)
// Menu image uses remote URL from config.menuImage

import makeWASocket, { useSingleFileAuthState } from "@whiskeysockets/baileys";
import P from "pino";
import qrcode from "qrcode-terminal";

import fs from "fs";

const configPath = './config.json';
let config = {
  owner: "+923448166105",
  channel: "https://whatsapp.com/channel/0029VbBKWrA2v1Iu4KVE3A1H",
  group: "https://chat.whatsapp.com/KJ6qs3H2xC6AQPYRTaNBNm?mode=wwc",
  botName: "NIAZI-MD",
  menuImage: "https://i.ibb.co/WW3f9Mt9/shaban-md.jpg"
};

try {
  if (fs.existsSync(configPath)) {
    const raw = fs.readFileSync(configPath);
    const parsed = JSON.parse(raw);
    config = { ...config, ...parsed };
  }
} catch (e) {
  console.error("Failed to read config.json, using defaults.");
}

const { state, saveState } = useSingleFileAuthState('./auth_info.json');

async function start() {
  console.log(`Starting ${config.botName}...`);

  const sock = makeWASocket({
    logger: P({ level: 'silent' }),
    printQRInTerminal: true,
    auth: state,
    browser: [config.botName, "Chrome", "1.0.0"]
  });

  sock.ev.on('creds.update', saveState);

  sock.ev.on('messages.upsert', async (m) => {
    const msg = m.messages?.[0];
    if (!msg || msg.key.fromMe || !msg.message) return;

    const from = msg.key.remoteJid;
    const text = (msg.message.conversation) || (msg.message.extendedTextMessage?.text) || "";

    console.log(`[IN] ${from}: ${text}`);

    const lower = String(text || "").trim().toLowerCase();

    if (lower === 'hi' || lower === 'hello') {
      await sock.sendMessage(from, {
        text: `Hey! I'm ${config.botName} 🤖\nWelcome!\nJoin our official channel and group below:\n\nChannel: ${config.channel}\nGroup: ${config.group}\n\nType 'menu' to see commands.`
      });
      return;
    }

    if (lower === 'menu') {
      // send menu image using remote URL if present
      try {
        if (config.menuImage && config.menuImage.startsWith('http')) {
          await sock.sendMessage(from, {
            image: { url: config.menuImage },
            caption: `📜 ${config.botName} - Menu\n1) hi / hello - greet the bot\n2) about - bot info\n3) owner - owner contact\n4) ping - bot status\n5) time - current server time\n\nChannel: ${config.channel}\nGroup: ${config.group}`
          });
        } else {
          // fallback to text menu
          await sock.sendMessage(from, {
            text: `Menu:\n1) hi / hello\n2) about\n3) owner\n4) ping\n5) time\n\nChannel: ${config.channel}\nGroup: ${config.group}`
          });
        }
      } catch (err) {
        console.error('Failed to send menu image', err);
        await sock.sendMessage(from, { text: `Menu (image failed):\n1) hi / hello\n2) about\n3) owner\n4) ping\n5) time\n\nChannel: ${config.channel}\nGroup: ${config.group}` });
      }
      return;
    }

    if (lower === 'about') {
      await sock.sendMessage(from, {
        text: `${config.botName} is a WhatsApp MD bot built with Baileys and Node.js.\nOwner: ${config.owner}`
      });
      return;
    }

    if (lower === 'owner' || lower === '!owner') {
      await sock.sendMessage(from, {
        text: `Owner: Mr. Niazi\nWhatsApp: ${config.owner}\nChannel: ${config.channel}\nGroup: ${config.group}`
      });
      return;
    }

    if (lower === 'ping') {
      await sock.sendMessage(from, { text: '🏓 Pong! Bot is online.' });
      return;
    }

    if (lower === 'time') {
      await sock.sendMessage(from, { text: `🕒 Server time: ${new Date().toLocaleString()}` });
      return;
    }

    // Default echo
    await sock.sendMessage(from, { text: `You said: ${text}\n(Type 'menu' to see commands)` });
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, qr, lastDisconnect } = update;
    if (qr) {
      console.log('Scan this QR with WhatsApp -> Linked Devices -> Link a Device');
      qrcode.generate(qr, { small: false });
    }
    if (connection === 'open') {
      console.log(`${config.botName} is online.`);
    } else if (connection === 'close') {
      console.log('Connection closed, reconnecting...');
    }
  });
}

start().catch(err => console.error(err));
