README: How to push & run (GitHub repo: https://github.com/Niaziofficial/NIAZI-HACKER-.git)

1. Extract this ZIP
2. In project folder:
   git init
   git add .
   git commit -m "Initial commit - NIAZI-MD final"
   git branch -M main
   git remote add origin https://github.com/Niaziofficial/NIAZI-HACKER-.git
   git push -u origin main

3. Run locally:
   npm install
   npm start
   // scan QR in terminal