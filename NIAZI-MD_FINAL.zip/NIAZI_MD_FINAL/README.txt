NIAZI-MD Bot - Final (menu image set)

What's changed:
- Menu image URL set in config.menuImage: https://i.ibb.co/WW3f9Mt9/shaban-md.jpg
- 'menu' command now sends the image (remote URL) with caption listing commands + channel & group links.

Files:
- niazi_md.js  -> main bot
- config.json  -> owner, channel, group, botName, menuImage
- package.json -> npm config
- README_GITHUB.txt -> push & run guide
- .gitignore

How to run locally:
1) npm install
2) npm start
3) Scan QR from terminal (WhatsApp -> Linked Devices -> Link a Device)
4) Type 'menu' to receive menu image + caption.

Notes:
- The bot uses remote image URL. Make sure your server/device has internet access.
- If the remote image fails to send, bot falls back to text menu.